<?php
function validarFormulario($nome, $email, $senha, $idade, $genero, $cidade, $estado, $termos)
{
    $erros = [];

    if (empty($nome) || empty($email) || empty($senha) || empty($idade) || empty($genero) || empty($cidade) || empty($estado)) {
        $erros[] = "Por favor, preencha todos os campos.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = "O e-mail informado não é válido.";
    }

    if (strlen($senha) < 6) {
        $erros[] = "A senha deve conter pelo menos 6 caracteres.";
    } else {
        $senha = md5($senha);
    }
    if (strlen(trim($estado)) === 0) {
        $erros[] = "Por favor, selecione um estado.";
    }
    if (!filter_var($idade, FILTER_VALIDATE_INT) || $idade < 10 || $idade > 120) {
        $erros[] = "A idade deve ser um número inteiro entre 10 e 120.";
    }

    if ($termos !== 'Sim') {
        $erros[] = "Você deve aceitar os termos de uso.";
    }

    if (!empty($erros)) {
        echo "<div class='alert alert-danger'><ul>";
        foreach ($erros as $erro) {
            echo "<li>$erro</li>";
        }
        echo "</ul></div>";
    } else {
        $valores_formulario = [
            'nome'   => $nome,
            'email'  => $email,
            'senha'  => $senha,
            'idade'  => $idade,
            'genero' => $genero,
            'cidade' => $cidade,
            'estado' => $estado,
            'termos' => $termos
        ];
        $cookie_valor = serialize($valores_formulario);
        setcookie($nome, $cookie_valor, time() + (86400 * 7), "/");


        return $erros;
    }
}
