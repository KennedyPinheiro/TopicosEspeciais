<?php
require_once 'validador.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    $idade = $_POST['idade'] ?? '';
    $genero = $_POST['genero'] ?? '';
    $cidade = $_POST['cidade'] ?? '';
    $estado = $_POST['estado'] ?? '';
    $termos = isset($_POST['termos']) ? 'Sim' : 'Não';

    $erros = validarFormulario($nome, $email, $senha, $idade, $genero, $cidade, $estado, $termos);

    if (!empty($erros)) {
        echo "<div class='alert alert-danger'><ul>";
        foreach ($erros as $erro) {
            echo "<li>$erro</li>";
        }
        echo "</ul></div>";
        exit;
    }

    $senha_hash = md5($senha);

    $valores_formulario = [
        'nome'   => $nome,
        'email'  => $email,
        'senha'  => $senha_hash,
        'idade'  => $idade,
        'genero' => $genero,
        'cidade' => $cidade,
        'estado' => $estado,
        'termos' => $termos
    ];

    $usuarios = [];
    if (isset($_COOKIE['usuarios'])) {
        $usuarios = unserialize($_COOKIE['usuarios']);
    }

    $usuarios[$nome] = $valores_formulario;

    setcookie('usuarios', serialize($usuarios), time() + 3600);

    echo '<pre>';
    print_r($usuarios);
    echo '</pre>';
}
